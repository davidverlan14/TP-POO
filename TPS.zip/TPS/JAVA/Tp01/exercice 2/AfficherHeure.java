import java.util.Date; 
3. public class AfficherHeure{ 
4.  
5.     public static void main(String[] args) { 
6.         Date d = new Date(); 
7.         System.out.print("il est " + d.getHours() + " h "); 
8.         System.out.print(d.getMinutes()+ " m "); 
9.         System.out.println(d.getSeconds() + " s"); 
10.     } 
} 