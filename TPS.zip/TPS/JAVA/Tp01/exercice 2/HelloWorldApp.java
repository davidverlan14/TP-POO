 /** 
4.  * The HelloWorldApp class implements an application that 
5.  * simply prints "Hello World!" to standard output. 
6.  */ 
 public class HelloWorldApp { 
     public static void main(String[] args) { 
         System.out.println("Bonjour Ceci est mon premier progamme JAVA"); 
     } 
} 

